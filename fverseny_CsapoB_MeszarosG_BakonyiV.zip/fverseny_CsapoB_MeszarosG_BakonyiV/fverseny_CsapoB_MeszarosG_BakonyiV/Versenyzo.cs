﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fverseny_CsapoB_MeszarosG_BakonyiV
{
    internal class Versenyzo
    {
        private int id;
        private int position;

        public static Random rnd;

        public Versenyzo(int id)
        {
            this.id = id;
            position = 0;
            rnd = new Random();
        }

        public int getId()
        {
            return id;
        }

        public void positionSetter(int step)
        {
            position += rnd.Next(1, step + 1);
        }

        public int positionGetter()
        {
            return position;
        }
    }
}
