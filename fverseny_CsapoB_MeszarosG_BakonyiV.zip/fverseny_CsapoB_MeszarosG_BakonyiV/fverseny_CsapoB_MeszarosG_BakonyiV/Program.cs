﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fverseny_CsapoB_MeszarosG_BakonyiV
{
    internal class Program
    {
        static void Start(Verseny race)
        {
            while (!race.nyert())
            {
                race.currentState();
                race.Round();
            }
            race.currentState();
        }

        static void Main(string[] args)
        {
           
            Verseny race = new Verseny(9, 50);
            Start(race);

            Console.ReadKey();
            
        }
    }
}
