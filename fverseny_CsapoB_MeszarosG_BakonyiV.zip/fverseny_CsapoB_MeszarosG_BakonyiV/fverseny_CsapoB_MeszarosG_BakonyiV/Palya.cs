﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fverseny_CsapoB_MeszarosG_BakonyiV
{
    internal class Palya
    {
        private int length;
        private int rows;

        public Palya(int length, int rows)
        {
            this.length = length;
            this.rows = rows;
        }

        public int getLength()
        {
            return length;
        }

        public int getRows()
        {
            return rows;
        }
    }
}
