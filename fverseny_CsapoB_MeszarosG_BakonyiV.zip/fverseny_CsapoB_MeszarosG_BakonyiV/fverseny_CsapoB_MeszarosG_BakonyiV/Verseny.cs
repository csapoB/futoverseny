﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace fverseny_CsapoB_MeszarosG_BakonyiV
{
    internal class Verseny
    {
        private Palya field;
        private List<Versenyzo> contestants;

        public Verseny(int num_of_contestants, int length_of_field)
        {
            field = new Palya(length_of_field, num_of_contestants);

            contestants = new List<Versenyzo>();

            for (int i = 0; i < num_of_contestants; i++)
            {
                contestants.Add(new Versenyzo(i + 1));
            }
        }

        public void currentState()
        {
            Thread.Sleep(500);
            Console.Clear();
            for (int i = 0; i < field.getLength() + 4; i++)
            {
                Console.Write("-");
            }
            if (contestants[0].positionGetter() == 0)
            {
                for (int y = 0; y < contestants.Count; y++)
                {
                    Console.Write($"\n{y + 1}|");
                    for (int x = 0; x < field.getLength(); x++)
                    {
                        Console.Write(" ");
                    }
                    Console.Write("|\n");
                    for (int i = 0; i < field.getLength() + 4; i++)
                    {
                        Console.Write("-");
                    }
                }
            }
            else
            {
                if (!nyert())
                {
                    for (int y = 0; y < contestants.Count; y++)
                    {
                        Console.Write($"\n |");
                        for (int x = 0; x < field.getLength(); x++)
                        {
                            if (x == contestants[y].positionGetter())
                            {
                                Console.Write(y + 1);
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                        Console.Write("|\n");
                        for (int i = 0; i < field.getLength() + 4; i++)
                        {
                            Console.Write("-");
                        }
                    }
                }
                else
                {
                    List<int> Winners = new List<int>();
                    for (int y = 0; y < contestants.Count; y++)
                    {
                        Console.Write($"\n |");
                        if (contestants[y].positionGetter() >= field.getLength())
                        {
                            Winners.Add(y);
                        }
                        for (int x = 0; x < field.getLength(); x++)
                        {
                            if (x == contestants[y].positionGetter())
                            {
                                Console.Write(y + 1);
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                        Console.Write("|\n");
                        for (int i = 0; i < field.getLength() + 4; i++)
                        {
                            Console.Write("-");
                        }
                    }
                    Console.Write("\nA nyertes(ek): ");
                    for (int w = 0; w < Winners.Count; w++)
                    {
                        Console.Write($"{Winners[w] + 1} ");
                    }
                }
            }
        }

        public bool nyert()
        {
            int i = 0;
            while (i < field.getRows() && contestants[i].positionGetter() < field.getLength())
            {
                i++;
            }
            return i < field.getRows();
        }

        public Palya getField()
        {
            return field;
        }

        public void Round()
        {
            for (int i = 0; i < contestants.Count; i++)
            {
                contestants[i].positionSetter(5);
            }
        }
    }
}
